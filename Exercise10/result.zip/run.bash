vcs -full64 -licqueue -timescale=1ns/1ns +vcs+flush+all +warn=all -sverilog -ntb_opts dtm testbench.sv 
./simv +vcs+lic+wait
urg  -dir simv.vdb -format text 
ls -l urgReport/*txt
cat urgReport/*txt